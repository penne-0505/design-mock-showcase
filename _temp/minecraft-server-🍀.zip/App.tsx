import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Narrative } from './components/Narrative';
import { Features } from './components/Features';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen antialiased selection:bg-emerald-200 selection:text-emerald-900">
      <Navbar />
      <main>
        <Hero />
        <Narrative />
        <Features />
      </main>
      <Footer />
    </div>
  );
};

export default App;