import { ReactNode } from 'react';

export interface SectionProps {
  children: ReactNode;
  className?: string;
  id?: string;
}

export interface RevealProps {
  children: ReactNode;
  width?: "fit-content" | "100%";
  delay?: number;
}
