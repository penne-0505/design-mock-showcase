import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { Button } from './ui/Button';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/forest/1920/1080" 
          alt="Peaceful forest landscape" 
          className="w-full h-full object-cover opacity-90 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-stone-50/30 via-stone-50/60 to-stone-50"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center pt-20">
        <Reveal delay={0.1} width="100%">
          <div className="mb-6 inline-block px-3 py-1 rounded-full border border-emerald-800/20 bg-emerald-50/50 backdrop-blur-sm text-emerald-800 text-xs font-medium tracking-wider">
            SINCE 2024
          </div>
        </Reveal>
        
        <Reveal delay={0.2} width="100%">
          <h1 className="serif text-5xl md:text-7xl font-medium text-stone-900 leading-[1.1] mb-8 tracking-tight">
            帰れる場所が、<br />
            ここにある。
          </h1>
        </Reveal>
        
        <Reveal delay={0.4} width="100%">
          <p className="text-stone-600 text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10 font-light">
            Minecraft Server 🍀 は、競い合うための場所ではありません。<br className="hidden md:block"/>
            終わりのない日常を、気の合う仲間と静かに紡ぐ。<br className="hidden md:block"/>
            そんな優しい時間が流れるコミュニティです。
          </p>
        </Reveal>

        <Reveal delay={0.6} width="100%">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              onClick={() => window.open('https://discord.com', '_blank')}
              icon={<ArrowRight size={18} />}
            >
              Discordに参加する
            </Button>
            <span className="text-stone-400 text-sm mt-4 sm:mt-0 sm:ml-4">
              審査や面接はありません
            </span>
          </div>
        </Reveal>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 animate-bounce">
        <span className="text-xs uppercase tracking-widest text-stone-500">Scroll</span>
        <div className="w-[1px] h-12 bg-stone-400"></div>
      </div>
    </section>
  );
};