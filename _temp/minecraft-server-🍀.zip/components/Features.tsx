import React from 'react';
import { Coffee, Map, Heart, Radio, Sun, BookOpen } from 'lucide-react';
import { Reveal } from './ui/Reveal';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => (
  <div className="p-8 bg-white rounded-3xl border border-stone-100 shadow-sm hover:shadow-md transition-shadow duration-300">
    <div className="w-12 h-12 flex items-center justify-center rounded-2xl bg-emerald-50 text-emerald-800 mb-6">
      {icon}
    </div>
    <h4 className="text-lg font-bold text-stone-800 mb-3">{title}</h4>
    <p className="text-stone-500 text-sm leading-relaxed">{description}</p>
  </div>
);

export const Features: React.FC = () => {
  const features = [
    {
      icon: <Coffee size={24} />,
      title: "落ち着いたサバイバル",
      description: "PvPや資源の奪い合いはありません。互いに譲り合い、協力し合う優しいサバイバルモードです。"
    },
    {
      icon: <Radio size={24} />,
      title: "Discord連携",
      description: "ゲーム内のチャットはDiscordと連携。ログインしていなくても、いつでも会話に参加できます。"
    },
    {
      icon: <Map size={24} />,
      title: "広がり続ける世界",
      description: "ダイナミックマップを導入。ブラウザから皆の開拓の様子や、現在地を眺めることができます。"
    },
    {
      icon: <Heart size={24} />,
      title: "初心者歓迎",
      description: "難しいコマンドや複雑なルールはありません。初めてのマルチプレイでも安心して参加できます。"
    },
    {
      icon: <Sun size={24} />,
      title: "美しい景観",
      description: "自然生成を活かした建築を推奨しています。四季折々のイベントも開催され、景色が彩られます。"
    },
    {
      icon: <BookOpen size={24} />,
      title: "物語のアーカイブ",
      description: "サーバー内の出来事や歴史はWikiのように記録され、いつでも思い出を振り返ることができます。"
    }
  ];

  return (
    <section id="features" className="bg-stone-100 py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <Reveal>
            <h2 className="serif text-3xl md:text-5xl text-stone-800 mb-6">心地よさのための仕組み</h2>
            <p className="text-stone-500">
              最新のプラグインと、昔ながらの温かさ。<br />
              快適に過ごすための環境を整えています。
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Reveal key={index} delay={index * 0.1}>
              <FeatureCard {...feature} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};