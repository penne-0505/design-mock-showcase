import React from 'react';
import { Reveal } from './ui/Reveal';

interface NarrativeItemProps {
  imageSrc: string;
  title: string;
  description: string;
  reversed?: boolean;
}

const NarrativeItem: React.FC<NarrativeItemProps> = ({ imageSrc, title, description, reversed = false }) => {
  return (
    <div className={`flex flex-col md:flex-row items-center gap-12 md:gap-24 py-24 ${reversed ? 'md:flex-row-reverse' : ''}`}>
      <div className="w-full md:w-1/2">
        <Reveal width="100%">
          <div className="relative group">
            <div className="absolute inset-0 bg-emerald-900/5 rounded-2xl transform rotate-3 group-hover:rotate-2 transition-transform duration-500"></div>
            <img 
              src={imageSrc} 
              alt={title} 
              className="relative w-full aspect-[4/3] object-cover rounded-2xl shadow-2xl shadow-stone-200"
            />
          </div>
        </Reveal>
      </div>
      
      <div className="w-full md:w-1/2">
        <Reveal delay={0.2}>
          <h3 className="serif text-3xl md:text-4xl text-stone-800 mb-6">{title}</h3>
          <p className="text-stone-600 leading-loose text-justify font-light">
            {description}
          </p>
        </Reveal>
      </div>
    </div>
  );
};

export const Narrative: React.FC = () => {
  return (
    <section id="about" className="max-w-7xl mx-auto px-6 md:px-12 py-20">
      <NarrativeItem 
        imageSrc="https://picsum.photos/seed/cozycabin/800/600"
        title="開拓というより、暮らすこと"
        description="広大な荒野を急いで埋め尽くす必要はありません。小さな小屋を建て、窓辺に花を飾り、夕日を眺める。効率よりも情緒を大切にする建築スタイルが、このサーバーの風景を作っています。あなたのペースで、あなたの物語を。"
      />
      <NarrativeItem 
        reversed
        imageSrc="https://picsum.photos/seed/campfire/800/600"
        title="緩やかにつながる、私たち"
        description="ボイスチャットは必須ではありません。テキストチャットで交わされる挨拶、共有されるスクリーンショット、時には無言で一緒に釣りをする時間。Discordを中心としたコミュニティは、近すぎず遠すぎない、心地よい距離感を保っています。"
      />
      <NarrativeItem 
        imageSrc="https://picsum.photos/seed/library/800/600"
        title="歴史の一部になる"
        description="ここでは定期的なマップリセットを行っていません。誰かが作った道が次の誰かの道となり、廃墟さえもが風景の一部として愛されます。あなたが今日置いた一つのブロックが、1年後の誰かの道標になるかもしれません。"
      />
    </section>
  );
};