import React, { useState, useEffect } from 'react';
import { Leaf } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-40 transition-all duration-500 ${scrolled ? 'py-4 bg-stone-50/80 backdrop-blur-md border-b border-stone-200/50' : 'py-8 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <div className="flex items-center gap-2 text-emerald-800">
          <Leaf size={20} fill="currentColor" className="opacity-80" />
          <span className="serif font-bold text-lg tracking-tight">Minecraft Server 🍀</span>
        </div>
        
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-stone-600">
          <a href="#about" className="hover:text-emerald-800 transition-colors">世界観</a>
          <a href="#features" className="hover:text-emerald-800 transition-colors">コミュニティ</a>
          <a href="#gallery" className="hover:text-emerald-800 transition-colors">風景</a>
        </div>

        <a 
          href="https://discord.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className={`hidden md:block px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${scrolled ? 'bg-emerald-800 text-white' : 'bg-white/80 text-emerald-900 shadow-sm backdrop-blur-sm hover:bg-emerald-50'}`}
        >
          Discordに参加
        </a>
      </div>
    </nav>
  );
};