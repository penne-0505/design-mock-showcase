import React from 'react';
import { Button } from './ui/Button';
import { MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-900 text-stone-400 py-24 relative overflow-hidden">
      {/* Abstract Background Decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10 pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-500 blur-[120px]"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-indigo-500 blur-[120px]"></div>
      </div>

      <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
        <h2 className="serif text-4xl md:text-5xl text-stone-200 mb-8">
          さあ、物語の続きを。
        </h2>
        <p className="text-stone-400 mb-12 max-w-lg mx-auto leading-relaxed">
          誰かを待つ必要はありません。<br />
          Discordの扉は、いつでも開かれています。
        </p>
        
        <div className="flex justify-center mb-16">
          <a href="https://discord.com" target="_blank" rel="noopener noreferrer">
            <Button 
              className="bg-emerald-600 hover:bg-emerald-500 text-white border-none px-10 py-4 text-lg"
              icon={<MessageCircle size={20} />}
            >
              Discordに参加する
            </Button>
          </a>
        </div>

        <div className="border-t border-stone-800 pt-12 flex flex-col md:flex-row justify-between items-center text-xs tracking-wider uppercase">
          <div className="mb-4 md:mb-0">
            &copy; 2024 Minecraft Server 🍀
          </div>
          <div className="flex gap-8">
            <a href="#" className="hover:text-emerald-500 transition-colors">利用規約</a>
            <a href="#" className="hover:text-emerald-500 transition-colors">プライバシーポリシー</a>
            <a href="#" className="hover:text-emerald-500 transition-colors">運営について</a>
          </div>
        </div>
      </div>
    </footer>
  );
};