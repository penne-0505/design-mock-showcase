import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ variant = 'primary', children, icon, className = '', ...props }) => {
  const baseStyles = "inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 transform active:scale-95";
  
  const variants = {
    primary: "bg-emerald-800 text-stone-50 hover:bg-emerald-900 shadow-lg shadow-emerald-900/10 hover:shadow-xl hover:shadow-emerald-900/20",
    secondary: "bg-stone-200 text-stone-800 hover:bg-stone-300",
    ghost: "bg-transparent text-stone-600 hover:text-stone-900 hover:bg-stone-100/50"
  };

  return (
    <button className={`${baseStyles} ${variants[variant]} ${className}`} {...props}>
      {children}
      {icon && <span className="ml-1">{icon}</span>}
    </button>
  );
};